﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuarterlySalesApp.Models
{
    public class FilterPrefix
    {
        public const string Year = "year-";
        public const string Quarter = "quarter-";
        public const string Employee = "employee-";
    }
}
